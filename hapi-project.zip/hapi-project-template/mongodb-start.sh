mkdir ~/data
docker run -d -p 27017:27017 -v ~/data:/data/db mongo
